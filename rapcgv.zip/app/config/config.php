<?php
// cơ sở dữ liệu

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'cgv');
// thu muc gốc D:\xampp\htdocs\rapcgv\app
define('APPROOT' , dirname(dirname(__FILE__)));
// thu muc gốc D:\xampp\htdocs\rapcgv\
define('ROOT' , dirname(dirname(dirname(__FILE__))));

// website
define('BASE_URL','http://localhost/rapcgv');
define('YOUTUBE','https://www.youtube.com/embed/');
define('SITENAME','Rạp chiếu phim cgv');

