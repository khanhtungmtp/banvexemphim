<script src="<?php echo BASE_URL;?>/public/js/slider.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL;?>/public/js/jquery-1.12.4.js"></script>
<script src="<?php echo BASE_URL;?>/public/js/3.3.1/jquery.min.js"></script>
<script src="<?php echo BASE_URL;?>/public/js/bootstrap.min.js"></script>

</body>
</html>